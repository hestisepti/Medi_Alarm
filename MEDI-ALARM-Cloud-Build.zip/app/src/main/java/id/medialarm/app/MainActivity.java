package id.medialarm.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText name, dose;
    TimePicker time;
    CheckBox daily;
    LinearLayout list;
    AlarmManager alarms;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        alarms=(AlarmManager)getSystemService(ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,24);
        TextView title=new TextView(this); title.setText("MEDI-ALARM\nPengingat Minum Obat"); title.setTextSize(24); title.setGravity(17); root.addView(title);
        name=new EditText(this); name.setHint("Nama obat"); root.addView(name);
        dose=new EditText(this); dose.setHint("Dosis sesuai resep"); root.addView(dose);
        time=new TimePicker(this); time.setIs24HourView(true); root.addView(time);
        daily=new CheckBox(this); daily.setText("Ulangi setiap hari"); daily.setChecked(true); root.addView(daily);
        Button save=new Button(this); save.setText("Simpan jadwal alarm"); root.addView(save);
        TextView note=new TextView(this); note.setText("Pastikan izin notifikasi dan alarm tepat diaktifkan. Ikuti dosis dan jadwal dari tenaga kesehatan."); root.addView(note);
        list=new LinearLayout(this); list.setOrientation(1); root.addView(list);
        save.setOnClickListener(v->saveAlarm());
        setContentView(root);
        showSaved();
    }
    void saveAlarm(){
        String n=name.getText().toString().trim(), d=dose.getText().toString().trim();
        if(n.isEmpty()||d.isEmpty()){ Toast.makeText(this,"Isi nama obat dan dosis",0).show(); return; }
        Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,time.getHour()); c.set(Calendar.MINUTE,time.getMinute()); c.set(Calendar.SECOND,0);
        if(c.getTimeInMillis()<=System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1);
        int id=(int)(System.currentTimeMillis() & 0x7fffffff);
        Intent i=new Intent(this,AlarmReceiver.class); i.putExtra("name",n); i.putExtra("dose",d); i.putExtra("daily",daily.isChecked()); i.putExtra("id",id);
        PendingIntent pi=PendingIntent.getBroadcast(this,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && !alarms.canScheduleExactAlarms()){
            startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));
            Toast.makeText(this,"Izinkan alarm tepat, lalu simpan jadwal kembali",1).show(); return;
        }
        if(daily.isChecked() && Build.VERSION.SDK_INT<23) alarms.setRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
        else alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
        getPreferences(0).edit().putString("alarm_"+id,n+"|"+d+"|"+c.getTimeInMillis()+"|"+daily.isChecked()).apply();
        Toast.makeText(this,"Jadwal alarm disimpan",0).show(); name.setText(""); dose.setText(""); showSaved();
    }
    void showSaved(){
        list.removeAllViews();
        Map<String,?> all=getPreferences(0).getAll();
        for(String k:all.keySet()) if(k.startsWith("alarm_")){ TextView t=new TextView(this); t.setPadding(0,12,0,12); t.setText("• "+all.get(k).toString().replace("|"," — ")); list.addView(t); }
    }
}
