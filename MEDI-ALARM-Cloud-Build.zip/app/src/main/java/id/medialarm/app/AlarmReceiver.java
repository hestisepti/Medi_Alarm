package id.medialarm.app;
import android.content.*; import android.app.*; import android.os.*;
public class AlarmReceiver extends BroadcastReceiver {
 public void onReceive(Context c, Intent i){
  String n=i.getStringExtra("name"), d=i.getStringExtra("dose");
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("medialarm","Pengingat Obat",NotificationManager.IMPORTANCE_HIGH));
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"medialarm"):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Waktunya minum obat").setContentText((n==null?"Obat":n)+" — "+(d==null?"ikuti resep":d)).setAutoCancel(true);
  nm.notify((int)System.currentTimeMillis(),b.build());
  if(i.getBooleanExtra("daily",false)){
   Intent again=new Intent(c,AlarmReceiver.class); again.putExtras(i);
   PendingIntent pi=PendingIntent.getBroadcast(c,i.getIntExtra("id",1),again,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
   long next=System.currentTimeMillis()+AlarmManager.INTERVAL_DAY;
   if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) return;
   am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi);
  }
 }
}
