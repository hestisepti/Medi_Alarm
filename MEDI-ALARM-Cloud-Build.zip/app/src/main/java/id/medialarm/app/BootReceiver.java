package id.medialarm.app;
import android.content.*; import android.app.*; import java.util.*;
public class BootReceiver extends BroadcastReceiver {
 public void onReceive(Context c, Intent i){
  // Android requires alarms to be rescheduled after reboot. This starter build
  // stores schedule labels only; re-entry and re-scheduling after reboot is a known
  // limitation to resolve and test before clinical or production use.
 }
}
