MEDI-ALARM — paket sumber untuk build otomatis GitHub Actions

PENTING:
- Ini BUKAN APK siap instal. APK dibuat oleh GitHub Actions setelah proyek diunggah ke repository.
- Hasil saat ini adalah prototipe awal, belum diuji pada perangkat Samsung/Android 16.
- Jangan digunakan sebagai satu-satunya pengingat obat untuk terapi penting.
- Pengguna harus mengaktifkan izin notifikasi dan alarm tepat.
- Keterbatasan yang masih harus diselesaikan sebelum disebut siap: penyimpanan jadwal yang kokoh, penjadwalan ulang harian yang tepat, pemulihan alarm setelah reboot, layar status sudah/belum diminum, dan pengujian lintas perangkat.
- Dosis dan waktu harus mengikuti instruksi dokter/apoteker.

Cara build:
1. Buat repository GitHub baru bernama MEDI-ALARM.
2. Unggah seluruh isi folder ini ke branch main, termasuk folder .github.
3. Buka tab Actions, jalankan "Build MEDI-ALARM APK".
4. Unduh artifact MEDI-ALARM-debug-apk dari hasil workflow.
